export const environment = {
  production: false,
  camunda: {
    clientId: '6ae2FsRMAXgt5nEvLDs-cfFb2Gce9ycR',
    clientSecret: '3OY~msZ38i3tp0FAyRt.AQp.l7wTaMF3VJsK2h7LmvYpFGGmC7gu~iaZFWErvXzj'
  }
};